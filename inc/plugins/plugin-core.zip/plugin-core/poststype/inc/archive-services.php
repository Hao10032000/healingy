<?php
/**
 * The template for displaying archive services.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package healingy
 */

get_header(); ?>
<?php 
$services_number_post = themesflat_get_opt( 'services_number_post' ) ? themesflat_get_opt( 'services_number_post' ) : 6;
$columns = themesflat_get_opt('services_grid_columns');
$themesflat_paging_style = themesflat_get_opt('services_archive_pagination_style');
$orderby = themesflat_get_opt('services_order_by');
$order = themesflat_get_opt('services_order_direction');
$exclude = themesflat_get_opt('services_exclude');
$show_filter = themesflat_get_opt('services_show_filter');
$filter_category_order = themesflat_get_opt('services_filter_category_order');	
$terms_slug = wp_list_pluck( get_terms( 'services_category','hide_empty=0'), 'slug' );
$filters =      wp_list_pluck( get_terms( 'services_category','hide_empty=0'), 'name','slug' );
$show_filter_class = '';

$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

$query_args = array(
    'post_type' => 'services',
    'orderby'   => $orderby,
    'order' => $order,    
    'paged' => $paged,    
    'posts_per_page' => $services_number_post,  
    'tax_query' => array(
        array(
            'taxonomy' => 'services_category',   
            'field'    => 'slug',                   
        	'terms'    => $terms_slug,
        ),
    ),
);	

if ( ! empty( $exclude ) ) {				
	if ( ! is_array( $exclude ) )
		$exclude = explode( ',', $exclude );

	$query_args['post__not_in'] = $exclude;
}
$query = new WP_Query( $query_args );
?>

<div class="themesflat-services-taxonomy sv-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wrap-content-area">
                    <div id="primary" class="content-area"> 
                        <main id="main" class="main-content" role="main"> 
                            <div class="wrap-services-post">
                                <?php 
                                
                                if( $query->have_posts() ) {
                                    while ( $query->have_posts() ) : $query->the_post();                	
                                    	?>           
                                        <div class="item">
                                            <div class="services-post services-post-<?php the_ID(); ?>">

                                            <div class="content"> 
                                                    <h5 class="title">
                                                        <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                                                    </h5>
                                                    <p class="description"><?php echo wp_trim_words( get_the_content(), 15, '' ); ?></p>
                                                </div>

                                                <div class="featured-post">
                                                    <a href="<?php echo get_the_permalink(); ?>">
                                                    <?php 
                                                        if ( has_post_thumbnail() ) { 
                                                            $themesflat_thumbnail = "themesflat-service-grid";                              
                                                            the_post_thumbnail( $themesflat_thumbnail );
                                                        }                                           
                                                    ?>
                                                    </a>
                                                </div>

                                                <div class="tf-button-container">
                                                        <a href="<?php echo esc_url( get_permalink() ) ?>" class="tf-button">
                                                            <span><?php esc_html_e('Read More', 'themesflat') ?></span>
                                                            <i aria-hidden="true" class=" icon-healingy-right1"></i>
                                                        </a>
                                                    </div>
                                            </div>
                                        </div>                    
                                        <?php 
                                    endwhile;
                                } else {
                                    get_template_part( 'template-parts/content', 'none' );
                                }
                                ?>            
                            </div>
                            <?php 
                                themesflat_pagination_posttype($query);
                                wp_reset_postdata();
                            ?>  
                        </main><!-- #main -->
                    </div><!-- #primary -->
                    <?php 
                    if ( themesflat_get_opt( 'services_layout' ) == 'sidebar-left' || themesflat_get_opt( 'services_layout' ) == 'sidebar-right' ) :
                        get_sidebar();
                    endif;
                    ?>
                </div>
            </div>
        </div>
    </div>
</div><!-- /.themesflat-services-taxonomy -->

<?php get_footer(); ?>