;(function($) {

    "use strict";   

    var tfpiechartmap = function() {
        $('.tf-pie-chart-inner .data-chart').each(function(){
            var max = $(this).data("index");
            let data_pie = '';
            for (let i = 0; i < max; i++) {
                data_pie = data_pie + $(this).data('number' + i) + ',';
            }
            

            let data_name = '';
            for (let i = 0; i < max; i++) {
                data_name =  data_name + $(this).data('desc' + i) + "/";
            }

            let data_color = '';
            for (let i = 0; i < max; i++) {
                data_color =  data_color + $(this).data('color' + i) + "/";
            }

            let arr = data_pie.split(',');
            let arr2 = data_name.split('/');
            let arr3 = data_color.split('/');
                const data1 = {
                    labels: arr2,
                    datasets: [{
                        
                        label: 'My First Dataset',
                        data: arr,
                        backgroundColor: arr3, 
                    }]
                };

                const config1 = {
                    type: 'doughnut',
                    data: data1,
                    width: 1000,
                    options: {
                        maintainAspectRatio: false,
                        plugins: {
                            legend: false, // Hide legend
                            tooltip: {
                                // Disable the on-canvas tooltip
                                enabled: false,
                
                                external: function(context) {
                                    // Tooltip Element
                                    let tooltipEl = document.getElementById('chartjs-tooltip');
                
                                    // Create element on first render
                                    if (!tooltipEl) {
                                        tooltipEl = document.createElement('div');
                                        tooltipEl.id = 'chartjs-tooltip';
                                        tooltipEl.innerHTML = '<table></table>';
                                        document.body.appendChild(tooltipEl);
                                    }
                
                                    // Hide if no tooltip
                                    const tooltipModel = context.tooltip;
                                    if (tooltipModel.opacity === 0) {
                                        tooltipEl.style.opacity = 0;
                                        return;
                                    }
                
                                    // Set caret Position
                                    tooltipEl.classList.remove('above', 'below', 'no-transform');
                                    if (tooltipModel.yAlign) {
                                        tooltipEl.classList.add(tooltipModel.yAlign);
                                    } else {
                                        tooltipEl.classList.add('no-transform');
                                    }
                
                                    function getBody(bodyItem) {
                                        return bodyItem.lines;
                                    }
                
                                    // Set Text
                                    if (tooltipModel.body) {
                                        const titleLines = tooltipModel.title || [];
                                        const bodyLines = tooltipModel.body.map(getBody);
                
                                        let innerHtml = '<thead>';
                
                                        titleLines.forEach(function(title) {
                                            innerHtml += '<tr><th>' + title + '</th></tr>';
                                        });
                                        innerHtml += '</thead><tbody>';
                
                                        bodyLines.forEach(function(body, i) {
                                            const colors = tooltipModel.labelColors[i];
                                            let style = 'background:' + colors.backgroundColor;
                                            style += '; border-color:' + colors.borderColor;
                                            style += '; border-width: 2px';
                                            const span = '<span style="' + style + '">' + body + '</span>';
                                            innerHtml += '<tr><td>' + span + '</td></tr>';
                                        });
                                        innerHtml += '</tbody>';
                
                                        let tableRoot = tooltipEl.querySelector('table');
                                        tableRoot.innerHTML = innerHtml;
                                    }
                
                                    const position = context.chart.canvas.getBoundingClientRect();
                                    const bodyFont = Chart.helpers.toFont(tooltipModel.options.bodyFont);
                
                                    // Display, position, and set styles for font
                                    tooltipEl.style.opacity = 1;
                                    tooltipEl.style.position = 'absolute';
                                    tooltipEl.style.left = position.left + window.pageXOffset + tooltipModel.caretX + 'px';
                                    tooltipEl.style.top = position.top + window.pageYOffset + tooltipModel.caretY + 'px';
                                    tooltipEl.style.font = bodyFont.string;
                                    tooltipEl.style.padding = tooltipModel.padding + 'px ' + tooltipModel.padding + 'px';
                                    tooltipEl.style.pointerEvents = 'none';
                                }
                            }
                        },
                        scales: {
                            y: {
                                display: false // Hide Y axis labels
                            },
                            x: {
                                display: false // Hide X axis labels
                            }
                        }   
                    }
                };
            
                const myChart1 = new Chart(
                document.getElementById('myChart1'),
                config1);
        });
    };

    
    

    $(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/tfpiechartmap.default', tfpiechartmap );       
    });

})(jQuery);
