<?php if (get_page_template_slug() != 'tpl/front-page.php') {
    echo "</div>";
    echo "</div>";
} ?>
</div><!-- /#boxed -->
<?php do_action( 'tf_footer' ); ?>
<?php wp_footer(); ?>
</body>
</html> 