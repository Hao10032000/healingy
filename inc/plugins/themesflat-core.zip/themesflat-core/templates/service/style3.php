<div class="item">				
    <div class="services-post " >
        <div class="features-image">
            <a href="<?php echo get_the_permalink(); ?>">
            <?php 
            $get_id_post_thumbnail = get_post_thumbnail_id();
            echo sprintf('<img src="%s" alt="image">', \Elementor\Group_Control_Image_Size::get_attachment_image_src( $get_id_post_thumbnail, 'thumbnail', $settings ));
            ?>
            </a>
        </div>
        <div class="content"> 
            <?php 
                $icon_1 = \Elementor\Addon_Elementor_Icon_manager_onatrix::render_icon( themesflat_get_opt_elementor('services_post_icon') );
                $icon_post_1 = '<div class="post-icon3"><div class="icon-3" >'.$icon_1.'</div></div>';
            ?>

            <?php if ( $settings['layout_style3'] == 'layout-1' ): ?>
            <div class="group-title">
                <?php if ( $settings['show_icon'] == 'yes' ): ?>
                <?php echo $icon_post_1; ?>
                <?php endif; ?>
                <h4 class="title">
                    <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                </h4>
            </div>
            <?php endif; ?>

            <?php if ( $settings['show_category'] == 'yes' ): ?>
                <?php echo esc_attr ( the_terms( get_the_ID(), 'services_category', '', ', ', '' ) ); ?>
            <?php endif; ?>

            <?php if ( $settings['layout_style3'] == 'layout-2' ): ?>
                <?php if ( $settings['show_icon'] == 'yes' ): ?>
                <?php echo $icon_post_1; ?>
                <?php endif; ?>
                <h4 class="title">
                    <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                </h4>
            <?php endif; ?>

            <?php if ( $settings['show_exc'] == 'yes' ): ?>
            <p class="description"><?php echo wp_trim_words( get_the_content(), $settings['excerpt_lenght'], '' ); ?></p>
            <?php endif; ?>
            <?php if ( $settings['show_button'] == 'yes' ): ?>
            <div class="tf-button-container">
                <a href="<?php echo esc_url( get_permalink() ) ?>" class="tf-button">
                    <span><?php echo esc_attr( $settings['button_text'] ); ?></span>
                    <?php echo \Elementor\Addon_Elementor_Icon_manager_onatrix::render_icon( $settings['post_icon_readmore'], [ 'aria-hidden' => 'true' ] );?>
                </a>
            </div>
            <?php endif; ?>
        </div>
        
    </div>
</div>