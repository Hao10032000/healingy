<div class="item">				
    <div class="services-post  <?php echo esc_attr( $settings['layout-content'] ); ?>">
        <div class="content"> 
        <?php 
            $icon_2 = themesflat_get_opt_elementor('services_post_icon_2')['url'];
            $icon_post_2 = sprintf('<div class="icon-img" ><img src="%1s" alt="images"/></div>',$icon_2);
        ?>
            <?php if ( $settings['show_icon'] == 'yes' ): ?>
        <?php echo $icon_post_2; ?>
        <?php endif; ?>
            <div class="inner">
                <h4 class="title">
                    <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                </h4>
                <?php if ( $settings['show_category'] == 'yes' ): ?>
                <?php echo esc_attr ( the_terms( get_the_ID(), 'services_category', '', ', ', '' ) ); ?>
            <?php endif; ?>
                <?php if ( $settings['show_exc'] == 'yes' ): ?>
                <p class="description"><?php echo wp_trim_words( get_the_content(), $settings['excerpt_lenght'], '' ); ?></p>
                <?php endif; ?>
                <?php if ( $settings['show_button'] == 'yes' ): ?>
                <div class="tf-button-container">
                    <a href="<?php echo esc_url( get_permalink() ) ?>" class="tf-button">
                        <span><?php echo esc_attr( $settings['button_text'] ); ?></span>
                        <?php echo \Elementor\Addon_Elementor_Icon_manager_onatrix::render_icon( $settings['post_icon_readmore'], [ 'aria-hidden' => 'true' ] );?>
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>