<?php
class TFPieChart_Map_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'tfpiechartmap';
    }
    
    public function get_title() {
        return esc_html__( 'TF Pie Chart Map', 'themesflat-core' );
    }

    public function get_icon() {
        return 'eicon-counter-circle';
    }
    
    public function get_categories() {
        return [ 'themesflat_addons' ];
    }

    public function get_style_depends() {
        return ['tfc-piechart'];
    }

    public function get_script_depends() {
        return ['appear', 'piechart', 'tfc-piechart','piechart-map','tf-piechart-map'];
    }

	protected function register_controls() {
        // Start Setting
            $this->start_controls_section( 
                    'section_setting',
                    [
                        'label' => esc_html__('Setting', 'themesflat-core'),
                    ]
                );

                $repeater = new \Elementor\Repeater();

                $repeater->add_control(
                    'name_pie',
                    [
                        'label' => esc_html__( 'Name elements', 'themesflat-core' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'January', 'themesflat-core' ),
                        'label_block' => true,
                    ]
                );
    
                $repeater->add_control(
                    'desc_pie',
                    [
                        'label' => esc_html__( 'Description elements', 'themesflat-core' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( '$1.246.723', 'themesflat-core' ),
                        'label_block' => true,
                    ]
                );

                $repeater->add_control(
                    'number_pie',
                    [
                        'label' => esc_html__( 'Description elements', 'themesflat-core' ),
                        'type' => \Elementor\Controls_Manager::NUMBER,
                        'default' => esc_html__( '50', 'themesflat-core' ),
                        'label_block' => true,
                    ]
                );

                $repeater->add_control(
                    'color_pie',
                    [
                        'label' => esc_html__( 'Description elements', 'themesflat-core' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'default' => '#8599A6',
                        'label_block' => true,
                    ]
                );
    
                $this->add_control(
                    'list_pie',
                    [
                        'label' => esc_html__( 'List', 'themesflat-core' ),
                        'type' => \Elementor\Controls_Manager::REPEATER,
                        'fields' => $repeater->get_controls(),
                        'default' => [
                            [
                                'name_pie' => esc_html__( 'January', 'tf-addon-for-elementer' ),
                                'desc_pie' => esc_html__( '$1.246.723', 'tf-addon-for-elementer' ),
                                'number_pie' => esc_html__( '30', 'tf-addon-for-elementer' ),
                                'color_pie' => esc_html__( '#8599A6', 'tf-addon-for-elementer' ),
                            ],
                            [
                                'name_pie' => esc_html__( 'February', 'tf-addon-for-elementer' ),
                                'desc_pie' => esc_html__( '$1.246.723', 'tf-addon-for-elementer' ),
                                'number_pie' => esc_html__( '30', 'tf-addon-for-elementer' ),
                                'color_pie' => esc_html__( '#D9C3A9', 'tf-addon-for-elementer' ),
                            ],
                            [
                                'name_pie' => esc_html__( 'March', 'tf-addon-for-elementer' ),
                                'desc_pie' => esc_html__( '$1.246.723', 'tf-addon-for-elementer' ),
                                'number_pie' => esc_html__( '40', 'tf-addon-for-elementer' ),
                                'color_pie' => esc_html__( '#95A9A1', 'tf-addon-for-elementer' ),
                            ],
                        ],
                    ]
                );



                $this->add_control( 
                    'show_content_inner',
                    [
                        'label' => esc_html__( 'Show Content Inner', 'themesflat-core' ),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => esc_html__( 'Show', 'themesflat-core' ),
                        'label_off' => esc_html__( 'Hide', 'themesflat-core' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                    ]
                );

                $this->add_control( 
                    'show_table',
                    [
                        'label' => esc_html__( 'Show Table', 'themesflat-core' ),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => esc_html__( 'Show', 'themesflat-core' ),
                        'label_off' => esc_html__( 'Hide', 'themesflat-core' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                    ]
                );
                

            $this->end_controls_section();
        // /.End Setting

        
		// Start Layout        
			$this->start_controls_section( 
				'section_content_layout',
	            [
	                'label' => esc_html__('Content Inner', 'themesflat-core'),
	            ]
	        );	

            $this->add_control(
                'sub_inner',
                [
                    'label' => esc_html__( 'Subtitle', 'themesflat-core' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'The total profit earned', 'themesflat-core' ),
                ]
            );

            $this->add_control(
                'title_inner',
                [
                    'label' => esc_html__( 'Title', 'themesflat-core' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( '$4.473.187', 'themesflat-core' ),
                ]
            );

        $this->end_controls_section();
        // /.End Setting

        // Start Content Style 
		    $this->start_controls_section( 
		    	'section_style_content',
	            [
	                'label' => esc_html__( 'Style', 'themesflat-core' ),
	                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
	            ]
	        ); 

            $this->add_responsive_control( 
	        	'chart_width',
				[
					'label' => esc_html__( 'Width Chart', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .tf-pie-chart .chart-bar' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};max-width: {{SIZE}}{{UNIT}};',
					],
				]
			);

            $this->add_responsive_control( 
	        	'chartinner_width',
				[
					'label' => esc_html__( 'Width Chart Inner', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .tf-pie-chart .chart-bar .content-chart' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
					],
				]
			);

            $this->add_group_control( 
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'charinner_border',
                    'label' => esc_html__( 'Chart Inner Border', 'themesflat-core' ),
                    'selector' => '{{WRAPPER}} .tf-pie-chart .chart-bar .content-chart',
                ]
            );

            $this->add_control( 
                'chartinner_bg',
                [
                    'label' => esc_html__( 'Chart Inner Background Color', 'themesflat-core' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .tf-pie-chart .chart-bar .content-chart' => 'background-color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_control( 
                'chartinner_sub',
                [
                    'label' => esc_html__( 'Chart Inner Subtile Color', 'themesflat-core' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .tf-pie-chart .chart-bar .content-chart .sub' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_control( 
                'chartinner_title',
                [
                    'label' => esc_html__( 'Chart Inner Tile Color', 'themesflat-core' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .tf-pie-chart .chart-bar .content-chart h3' => 'color: {{VALUE}};',
                    ],
                ]
            );

        $this->end_controls_section();
        // /.End Setting

	}

	protected function render($instance = []) {
		$settings = $this->get_settings_for_display();

        $this->add_render_attribute( 'tf_pie_chart', ['id' => "tf-pie-chart-{$this->get_id()}", 'class' => ['tf-pie-chart'], 'data-tabid' => $this->get_id()] );

		?>
        <div <?php echo $this->get_render_attribute_string('tf_pie_chart'); ?>>
            <div class="tf-pie-chart-inner">
                <div class="chart-bar">
                    <canvas id="myChart1" class="data-chart"
                    <?php $count = 0; foreach ( $settings['list_pie'] as $index => $item ) { ?>
                       <?php $count++; ?>
                     data-number<?php echo $index; ?>="<?php echo esc_attr($item['number_pie']); ?>"
                     data-name<?php echo $index; ?>="<?php echo esc_attr($item['name_pie']); ?>"
                     data-desc<?php echo $index; ?>="<?php echo esc_attr($item['desc_pie']); ?>"
                     data-color<?php echo $index; ?>="<?php echo esc_attr($item['color_pie']); ?>"
                     <?php } ?>data-index="<?php echo $count; ?>"></canvas>
                     <?php if ( $settings['show_content_inner'] == 'yes' ): ?>
                     <div class="content-chart">
                        <div class="ineer">
                           <?php if ( $settings['sub_inner'] != '' ) { ?>
                            <div class="sub"><?php echo esc_attr( $settings['sub_inner'] ); ?></div>
                            <?php } ?>
                            <?php if ( $settings['title_inner'] != '' ) { ?>
                            <h3><?php echo esc_attr( $settings['title_inner'] ); ?></h3>
                            <?php } ?>
                        </div>
                     </div>
                     <?php endif; ?>
                     <?php if ( $settings['show_table'] == 'yes' ): ?>
                     <div class="table-chart">
                         <ul>
                             <?php foreach ( $settings['list_pie'] as $index => $item ) { ?>
                            <li>
                                <div class="top">
                                    <div class="color-chart" style="background: <?php echo esc_attr($item['color_pie']); ?>"></div>
                                    <div class="time"><?php echo esc_attr($item['name_pie']); ?></div>
                                </div>
                                <div class="bot">
                                    <h4><?php echo esc_attr($item['desc_pie']); ?></h4>
                                </div>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>



        <?php
	}

}